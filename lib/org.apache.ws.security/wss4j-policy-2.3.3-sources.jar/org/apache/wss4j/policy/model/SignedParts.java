/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.wss4j.policy.model;

import org.apache.neethi.Policy;
import org.apache.wss4j.policy.SPConstants;

import javax.xml.namespace.QName;
import java.util.List;

public class SignedParts extends AbstractSecuredParts {

    private boolean signAllHeaders;

    public SignedParts(SPConstants.SPVersion version, boolean body, Attachments attachments,
                       List<Header> headers, boolean signAllHeaders) {
        super(version, body, attachments, headers);

        this.signAllHeaders = signAllHeaders;
    }

    @Override
    public QName getName() {
        return getVersion().getSPConstants().getSignedParts();
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof SignedParts)) {
            return false;
        }

        SignedParts that = (SignedParts)object;
        if (signAllHeaders != that.signAllHeaders) {
            return false;
        }

        return super.equals(object);
    }

    @Override
    public int hashCode() {
        int result = 17;
        result = 31 * result + Boolean.hashCode(signAllHeaders);

        return 31 * result + super.hashCode();
    }

    @Override
    protected AbstractSecurityAssertion cloneAssertion(Policy nestedPolicy) {
        return new SignedParts(getVersion(), isBody(),
                getAttachments() == null ? null : (Attachments) getAttachments().clone(nestedPolicy),
                getHeaders(), isSignAllHeaders());
    }

    public boolean isSignAllHeaders() {
        return signAllHeaders;
    }

    protected void setSignAllHeaders(boolean signAllHeaders) {
        this.signAllHeaders = signAllHeaders;
    }
}
