/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.cxf.ws.rm.blueprint;

import org.w3c.dom.Element;

import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.apache.cxf.configuration.blueprint.SimpleBPBeanDefinitionParser;
import org.apache.cxf.ws.rm.persistence.jdbc.RMTxStore;

/**
 * This class provides some common functions used by the two BP TxStore bean definition parsers
 * in this package.
 *
 */
public class RMBPTxStoreBeanDefinitionParser extends SimpleBPBeanDefinitionParser {

    public RMBPTxStoreBeanDefinitionParser() {
        super(RMTxStore.class);
    }

    @Override
    protected void parseChildElements(Element element, ParserContext ctx, MutableBeanMetadata bean) {
        super.parseChildElements(element, ctx, bean);

        bean.setInitMethod("init");
        bean.setDestroyMethod("destroy");
    }

    @Override
    protected void mapAttribute(MutableBeanMetadata bean, Element e, String name, String val,
                                ParserContext context) {
        if ("dataSource".equals(name)) {
            if (val != null && val.trim().length() > 0) {
                bean.addProperty("dataSource", createRef(context, val));
            }
        } else {
            super.mapAttribute(bean, e, name, val, context);
        }
    }

}
