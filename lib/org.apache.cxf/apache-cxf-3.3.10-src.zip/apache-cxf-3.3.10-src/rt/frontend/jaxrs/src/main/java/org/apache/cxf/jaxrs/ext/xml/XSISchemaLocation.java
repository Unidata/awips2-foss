/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.cxf.jaxrs.ext.xml;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This annotation can be used to simplify adding
 * xsi:schemaLocation attributes
 */
@Target({ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface XSISchemaLocation {
    /**
     * Schema location
     * By default it is assumed to be relative to a base URI of the web application
     */
    String value();

    /**
     * If the location is relative and this property is set to true then
     * the location will be resolved against the base URI of the web application
     */
    boolean resolve() default true;

    /**
     * Can be used to get xsi:noNamespaceSchemaLocation produced.
     * By default, xsi:schemaLocation will be set.
     */
    boolean noNamespace() default false;
}
