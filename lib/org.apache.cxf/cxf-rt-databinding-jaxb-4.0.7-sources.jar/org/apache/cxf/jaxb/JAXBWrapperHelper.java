/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.cxf.jaxb;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import jakarta.xml.bind.JAXBElement;
import org.apache.cxf.databinding.AbstractWrapperHelper;

/**
 *
 */
public class JAXBWrapperHelper extends AbstractWrapperHelper {
    protected final Method[] jaxbObjectMethods;
    protected final Object objectFactory;

    protected JAXBWrapperHelper(Class<?> wt, Method[] sets, Method[] gets,
                                Method[] jaxbs, Field[] f, Object of) {
        super(wt, sets, gets, f);
        jaxbObjectMethods = jaxbs;
        objectFactory = of;
    }

    @Override
    protected Object createWrapperObject(Class<?> typeClass) throws Exception {
        return typeClass.getDeclaredConstructor().newInstance();
    }

    @Override
    protected Object getWrapperObject(Object object) {
        return object;
    }

    @Override
    protected Object getValue(Method method, Object in) throws IllegalAccessException,
        InvocationTargetException {
        if ("jakarta.xml.bind.JAXBElement".equals(method.getReturnType().getCanonicalName())) {
            JAXBElement<?> je = (JAXBElement<?>)method.invoke(in);
            return je == null ? je : je.getValue();
        }
        return method.invoke(in);
    }

    @Override
    protected Object getPartObject(int index, Object object) throws Exception {
        Object result = object;
        if (jaxbObjectMethods[index] != null) {
            result = jaxbObjectMethods[index].invoke(objectFactory, object);
        }
        return result;
    }
}
