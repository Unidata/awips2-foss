/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.cxf.tools.wsdlto.frontend.jaxws.customization;


import java.io.Serializable;

import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.xml.namespace.QName;

import org.w3c.dom.Element;


public class JAXWSBindingDeserializer implements ExtensionDeserializer, Serializable {

    private static final long serialVersionUID = -4016144719848135088L;

    public JAXWSBindingDeserializer() {

    }

    public ExtensibilityElement unmarshall(@SuppressWarnings("rawtypes") Class parentType,
                                           QName elementType,
                                           Element el,
                                           Definition def,
                                           ExtensionRegistry extReg) throws WSDLException {
        JAXWSBinding jaxwsBinding = (JAXWSBinding)extReg.createExtension(parentType, elementType);

        jaxwsBinding.setElementType(elementType);
        jaxwsBinding.setElement(el);
        jaxwsBinding.setDocumentBaseURI(def.getDocumentBaseURI());

        JAXWSBindingParser parser = new JAXWSBindingParser(extReg);
        parser.parseElement(jaxwsBinding, el);

        return jaxwsBinding;
    }
}
