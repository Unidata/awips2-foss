/*
 * Copyright (c) 1998-2020 John Caron and University Corporation for Atmospheric Research/Unidata
 * See LICENSE for license information.
 */

package ucar.nc2.grib.collection;

import com.google.common.collect.ImmutableList;
import org.slf4j.Logger;
import ucar.ma2.*;
import ucar.nc2.*;
import ucar.nc2.constants.AxisType;
import ucar.nc2.constants.CDM;
import ucar.nc2.constants.CF;
import ucar.nc2.constants._Coordinate;
import ucar.nc2.dataset.VariableDS;
import ucar.nc2.grib.*;
import ucar.nc2.grib.collection.GribIosp.Time2Dinfo;
import ucar.nc2.grib.collection.GribIosp.Time2DinfoType;
import ucar.nc2.grib.coord.Coordinate;
import ucar.nc2.grib.coord.CoordinateEns;
import ucar.nc2.grib.coord.CoordinateRuntime;
import ucar.nc2.grib.coord.CoordinateTime;
import ucar.nc2.grib.coord.CoordinateTime2D;
import ucar.nc2.grib.coord.CoordinateTimeAbstract;
import ucar.nc2.grib.coord.CoordinateTimeIntv;
import ucar.nc2.grib.coord.CoordinateVert;
import ucar.nc2.grib.coord.EnsCoordValue;
import ucar.nc2.grib.coord.TimeCoordIntvValue;
import ucar.nc2.grib.coord.VertCoordType;
import ucar.nc2.grib.coord.VertCoordValue;
import ucar.nc2.grib.grib2.Grib2Utils;
import ucar.nc2.time.Calendar;
import ucar.unidata.geoloc.projection.RotatedPole;
import ucar.unidata.util.Parameter;
import java.util.Formatter;
import java.util.List;

/**
 * Grib Collection IOSP helper, for builders.
 */
class GribIospBuilder {
  final private GribIosp iosp;
  final private boolean isGrib1;
  final private org.slf4j.Logger logger;
  final private GribCollectionImmutable gribCollection;
  final private ucar.nc2.grib.GribTables gribTable;

  GribIospBuilder(GribIosp iosp, boolean isGrib1, Logger logger, GribCollectionImmutable gribCollection,
      GribTables gribTable) {
    this.iosp = iosp;
    this.isGrib1 = isGrib1;
    this.logger = logger;
    this.gribCollection = gribCollection;
    this.gribTable = gribTable;
  }

  void addGroup(Group.Builder parent, GribCollectionImmutable.GroupGC group, GribCollectionImmutable.Type gctype,
      boolean useGroups) {
    Group.Builder g;
    if (useGroups) {
      if (parent.findGroupLocal(group.getId()).isPresent()) {
        logger.warn("Duplicate Group - skipping");
        return;
      }
      g = Group.builder();
      g.setName(group.getId());
      g.addAttribute(new Attribute(CDM.LONG_NAME, group.getDescription()));
      parent.addGroup(g);
    } else {
      g = parent;
    }

    makeGroup(g, group, gctype);
  }

  private void makeGroup(Group.Builder g, GribCollectionImmutable.GroupGC group, GribCollectionImmutable.Type gctype) {
    GdsHorizCoordSys hcs = group.getGdsHorizCoordSys();
    String grid_mapping = hcs.getName() + "_Projection";

    String horizDims;

    boolean isRotatedLatLon = !isGrib1 && hcs.proj instanceof RotatedPole;
    boolean isLatLon2D = !isGrib1 && Grib2Utils.isCurvilinearOrthogonal(hcs.template, gribCollection.getCenter());
    boolean isLatLon = isGrib1 ? hcs.isLatLon() : Grib2Utils.isLatLon(hcs.template, gribCollection.getCenter());

    if (isRotatedLatLon) {
      Variable.Builder<?> hcsV = Variable.builder().setName(grid_mapping).setDataType(DataType.INT);
      g.addVariable(hcsV);
      hcsV.setCachedData(Array.factory(DataType.INT, new int[0], new int[] {0}), false);
      for (Parameter p : hcs.proj.getProjectionParameters()) {
        hcsV.addAttribute(new Attribute(p));
      }

      horizDims = "rlat rlon";
      g.addDimension(new Dimension("rlat", hcs.ny));
      g.addDimension(new Dimension("rlon", hcs.nx));
      Variable.Builder<?> rlat = Variable.builder().setName("rlat").setDataType(DataType.FLOAT).setParentGroupBuilder(g)
          .setDimensionsByName("rlat");
      g.addVariable(rlat);
      rlat.addAttribute(new Attribute(CF.STANDARD_NAME, CF.GRID_LATITUDE));
      rlat.addAttribute(new Attribute(CDM.UNITS, CDM.RLATLON_UNITS));
      rlat.setCachedData(Array.makeArray(DataType.FLOAT, hcs.ny, hcs.starty, hcs.dy), false);
      Variable.Builder<?> rlon = Variable.builder().setName("rlon").setDataType(DataType.FLOAT).setParentGroupBuilder(g)
          .setDimensionsByName("rlon");
      g.addVariable(rlon);
      rlon.addAttribute(new Attribute(CF.STANDARD_NAME, CF.GRID_LONGITUDE));
      rlon.addAttribute(new Attribute(CDM.UNITS, CDM.RLATLON_UNITS));
      rlon.setCachedData(Array.makeArray(DataType.FLOAT, hcs.nx, hcs.startx, hcs.dx), false);
    } else if (isLatLon2D) { // CurvilinearOrthogonal - lat and lon fields must be present in the file
      horizDims = "lat lon";

      // LOOK - assume same number of points for all grids
      g.addDimension(new Dimension("lon", hcs.nx));
      g.addDimension(new Dimension("lat", hcs.ny));

    } else if (isLatLon) {
      // make horiz coordsys coordinate variable
      Variable.Builder<?> hcsV = Variable.builder().setName(grid_mapping).setDataType(DataType.INT);
      g.addVariable(hcsV);
      hcsV.setCachedData(Array.factory(DataType.INT, new int[0], new int[] {0}), false);
      for (Parameter p : hcs.proj.getProjectionParameters()) {
        hcsV.addAttribute(new Attribute(p));
      }

      horizDims = "lat lon";
      g.addDimension(new Dimension("lon", hcs.nx));
      g.addDimension(new Dimension("lat", hcs.ny));

      Variable.Builder<?> lat = Variable.builder().setName("lat").setDataType(DataType.FLOAT).setParentGroupBuilder(g)
          .setDimensionsByName("lat");
      g.addVariable(lat);
      lat.addAttribute(new Attribute(CDM.UNITS, CDM.LAT_UNITS));
      if (hcs.getGaussianLats() != null) {
        lat.setCachedData(hcs.getGaussianLats(), false);
        lat.addAttribute(new Attribute(CDM.GAUSSIAN, "true"));
      } else {
        lat.setCachedData(Array.makeArray(DataType.FLOAT, hcs.ny, hcs.starty, hcs.dy), false);
      }

      Variable.Builder<?> lon = Variable.builder().setName("lon").setDataType(DataType.FLOAT).setParentGroupBuilder(g)
          .setDimensionsByName("lon");
      g.addVariable(lon);
      lon.addAttribute(new Attribute(CDM.UNITS, CDM.LON_UNITS));
      lon.setCachedData(Array.makeArray(DataType.FLOAT, hcs.nx, hcs.startx, hcs.dx), false);

    } else {
      // make horiz coordsys coordinate variable
      Variable.Builder<?> hcsV = Variable.builder().setName(grid_mapping).setDataType(DataType.INT);
      g.addVariable(hcsV);
      hcsV.setCachedData(Array.factory(DataType.INT, new int[0], new int[] {0}), false);
      for (Parameter p : hcs.proj.getProjectionParameters()) {
        hcsV.addAttribute(new Attribute(p));
      }

      horizDims = "y x";
      g.addDimension(new Dimension("x", hcs.nx));
      g.addDimension(new Dimension("y", hcs.ny));

      Variable.Builder<?> xcv =
          Variable.builder().setName("x").setDataType(DataType.FLOAT).setParentGroupBuilder(g).setDimensionsByName("x");
      g.addVariable(xcv);
      xcv.addAttribute(new Attribute(CF.STANDARD_NAME, CF.PROJECTION_X_COORDINATE));
      xcv.addAttribute(new Attribute(CDM.UNITS, "km"));
      xcv.setCachedData(Array.makeArray(DataType.FLOAT, hcs.nx, hcs.startx, hcs.dx), false);

      Variable.Builder<?> ycv =
          Variable.builder().setName("y").setDataType(DataType.FLOAT).setParentGroupBuilder(g).setDimensionsByName("y");
      g.addVariable(ycv);
      ycv.addAttribute(new Attribute(CF.STANDARD_NAME, CF.PROJECTION_Y_COORDINATE));
      ycv.addAttribute(new Attribute(CDM.UNITS, "km"));
      ycv.setCachedData(Array.makeArray(DataType.FLOAT, hcs.ny, hcs.starty, hcs.dy), false);
    }

    for (Coordinate coord : group.coords) {
      Coordinate.Type ctype = coord.getType();
      switch (ctype) {
        case runtime:
          if (gctype.isTwoD() || coord.getNCoords() == 1) {
            makeRuntimeCoordinate(g, (CoordinateRuntime) coord);
          }
          break;
        case timeIntv:
          makeTimeCoordinate1D(g, (CoordinateTimeIntv) coord);
          break;
        case time:
          makeTimeCoordinate1D(g, (CoordinateTime) coord);
          break;
        case vert:
          makeVerticalCoordinate(g, (CoordinateVert) coord);
          break;
        case ens:
          makeEnsembleCoordinate(g, (CoordinateEns) coord);
          break;
        case time2D:
          if (gctype.isUniqueTime()) {
            makeUniqueTimeCoordinate2D(g, (CoordinateTime2D) coord);
          } else {
            CoordinateTime2D time2D = (CoordinateTime2D) coord;
            if (time2D.isOrthogonal()) {
              String timeDimName = makeTimeOffsetOrthogonal(g, time2D);
              makeTimeCoordinate2D(g, time2D, timeDimName);
            } else if (time2D.isRegular()) {
              String timeDimName = makeTimeOffsetRegular(g, time2D);
              makeTimeCoordinate2D(g, time2D, timeDimName);
            } else {
              makeTimeCoordinate2D(g, time2D, make2dValidTimeDimensionName(time2D.getName()));
            }
          }
          break;
      }
    }

    for (GribCollectionImmutable.VariableIndex vindex : group.variList) {
      try (Formatter dimNames = new Formatter(); Formatter coordinateAtt = new Formatter()) {

        // do the times first
        Coordinate run = vindex.getCoordinate(Coordinate.Type.runtime);
        Coordinate time = vindex.getCoordinateTime();
        if (time == null) {
          throw new IllegalStateException("No time coordinate = " + vindex);
        }

        String timeDimName = time.getName();
        String timeCoordName = time.getName();

        if (time instanceof CoordinateTime2D) {
          CoordinateTime2D time2D = (CoordinateTime2D) time;
          if (!gctype.isUniqueTime() && (time2D.isOrthogonal() || time2D.isRegular())) {
            timeDimName = makeTimeOffsetName(time.getName());
          } else {
            timeDimName = make2dValidTimeDimensionName(time.getName());
            timeCoordName = make2dValidTimeCoordName(timeDimName); // TODO backport this to version 5
          }
        }

        boolean isRunScaler = (run != null) && run.getSize() == 1;

        switch (gctype) {
          case SRC: // GC: Single Runtime Collection [ntimes] (run, 2D) scalar runtime
            assert isRunScaler;
            dimNames.format("%s ", timeDimName);
            coordinateAtt.format("%s %s ", run.getName(), timeDimName);
            break;

          case MRUTP: // PC: Multiple Runtime Unique Time Partition [ntimes]
          case MRUTC: // GC: Multiple Runtime Unique Time Collection [ntimes]
            // case MRSTC: // GC: Multiple Runtime Single Time Collection [nruns, 1]
            // case MRSTP: // PC: Multiple Runtime Single Time Partition [nruns, 1] (run, 2D) ignore the run, its
            // generated from the 2D in
            dimNames.format("%s ", timeDimName);
            coordinateAtt.format("ref%s %s ", timeDimName, timeDimName);
            break;

          case MRC: // GC: Multiple Runtime Collection [nruns, ntimes] (run, 2D) use Both
          case TwoD: // PC: TwoD time partition [nruns, ntimes]
            assert run != null : "GRIB MRC or TWOD does not have run coordinate";
            if (isRunScaler) {
              dimNames.format("%s ", timeDimName);
            } else {
              dimNames.format("%s %s ", run.getName(), timeDimName);
            }
            coordinateAtt.format("%s %s ", run.getName(), timeCoordName);
            if (!timeDimName.equals(timeCoordName)) {
              coordinateAtt.format("%s ", timeDimName);
            }
            break;

          case Best: // PC: Best time partition [ntimes] (time) reftime is generated in makeTimeAuxReference()
          case BestComplete: // PC: Best complete time partition [ntimes]
            dimNames.format("%s ", timeDimName);
            coordinateAtt.format("ref%s %s ", timeDimName, timeDimName);
            break;

          default:
            throw new IllegalStateException("Uknown GribCollection TYpe = " + gctype);
        }

        // do other (vert, ens) coordinates
        for (Coordinate coord : vindex.getCoordinates()) {
          if (coord instanceof CoordinateTimeAbstract || coord instanceof CoordinateRuntime) {
            continue;
          }
          String name = coord.getName().toLowerCase();
          dimNames.format("%s ", name);
          coordinateAtt.format("%s ", name);
        }
        // do horiz coordinates
        dimNames.format("%s", horizDims);
        coordinateAtt.format("%s ", horizDims);

        String vname = iosp.makeVariableName(vindex);
        Variable.Builder<?> v = Variable.builder().setName(vname).setDataType(DataType.FLOAT).setParentGroupBuilder(g)
            .setDimensionsByName(dimNames.toString());
        g.addVariable(v);

        String desc = iosp.makeVariableLongName(vindex);
        v.addAttribute(new Attribute(CDM.LONG_NAME, desc));
        v.addAttribute(new Attribute(CDM.UNITS, iosp.makeVariableUnits(vindex)));

        GribTables.Parameter gp = iosp.getParameter(vindex);
        if (gp != null) {
          if (gp.getDescription() != null) {
            v.addAttribute(new Attribute(CDM.DESCRIPTION, gp.getDescription()));
          }
          if (gp.getAbbrev() != null) {
            v.addAttribute(new Attribute(CDM.ABBREV, gp.getAbbrev()));
          }
          v.addAttribute(new Attribute(CDM.MISSING_VALUE, gp.getMissing()));
          if (gp.getFill() != null) {
            v.addAttribute(new Attribute(CDM.FILL_VALUE, gp.getFill()));
          }
        } else {
          v.addAttribute(new Attribute(CDM.MISSING_VALUE, Float.NaN));
        }

        // horiz coord system
        if (isLatLon2D) { // special case of "LatLon Orthogononal"
          String s = iosp.searchCoord(Grib2Utils.getLatLon2DcoordType(desc), group.variList);
          if (s == null) { // its a 2D lat/lon coordinate
            v.setDimensionsByName(horizDims); // LOOK make this 2D and munge the units
            String units = desc.contains("Latitude of") ? CDM.LAT_UNITS : CDM.LON_UNITS;
            v.addAttribute(new Attribute(CDM.UNITS, units));

          } else { // its a variable using the coordinates described by s
            coordinateAtt.format("%s ", s);
          }
        } else {
          v.addAttribute(new Attribute(CF.GRID_MAPPING, grid_mapping));
        }
        v.addAttribute(new Attribute(CF.COORDINATES, coordinateAtt.toString()));

        // statistical interval type
        if (vindex.getIntvType() >= 0) {
          // LOOK find the time coordinate
          GribStatType statType = gribTable.getStatType(vindex.getIntvType());
          if (statType != null) {
            v.addAttribute(new Attribute(Grib.GRIB_STAT_TYPE, statType.toString()));
            CF.CellMethods cm = GribStatType.getCFCellMethod(statType);
            Coordinate timeCoord = vindex.getCoordinate(Coordinate.Type.timeIntv);
            if (cm != null && timeCoord != null) {
              v.addAttribute(new Attribute(CF.CELL_METHODS, timeCoord.getName() + ": " + cm));
            }
          } else {
            v.addAttribute(new Attribute(Grib.GRIB_STAT_TYPE, vindex.getIntvType()));
          }
        }

        gribCollection.addVariableAttributes(v.getAttributeContainer(), vindex);
        v.setSPobject(vindex);
      }
    }
  }

  private void makeRuntimeCoordinate(Group.Builder g, CoordinateRuntime rtc) {
    int n = rtc.getSize();
    boolean isScalar = (n == 1); // this is the case of runtime[1]
    String tcName = rtc.getName();
    String dims = isScalar ? null : rtc.getName(); // null means scalar
    if (!isScalar) {
      g.addDimension(new Dimension(tcName, n));
    }

    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(dims);
    g.addVariable(v);
    v.addAttribute(new Attribute(CDM.UNITS, rtc.getUnit()));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME_REFERENCE));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_RUNTIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));

    // lazy eval
    v.setSPobject(new Time2Dinfo(Time2DinfoType.reftime, null, rtc));
  }

  // time coordinates are unique
  // time(nruns, ntimes) -> time(ntimes) with dependent reftime(ntime) coordinate
  private void makeUniqueTimeCoordinate2D(Group.Builder g, CoordinateTime2D time2D) {
    CoordinateRuntime runtime = time2D.getRuntimeCoordinate();

    int countU = 0;
    for (int run = 0; run < time2D.getNruns(); run++) {
      CoordinateTimeAbstract timeCoord = time2D.getTimeCoordinate(run);
      countU += timeCoord.getSize();
    }
    int ntimes = countU;
    String tcName = time2D.getName();
    String timeDimName = make2dValidTimeDimensionName(tcName);

    g.addDimension(new Dimension(timeDimName, ntimes));
    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(timeDimName);
    g.addVariable(v);
    String units = runtime.getUnit(); // + " since " + runtime.getFirstDate();
    v.addAttribute(new Attribute(CDM.UNITS, units));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_VALID_TIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));

    // the data is not generated until asked for to save space
    if (!time2D.isTimeInterval()) {
      v.setSPobject(new Time2Dinfo(Time2DinfoType.offU, time2D, null));
    } else {
      v.setSPobject(new Time2Dinfo(Time2DinfoType.intvU, time2D, null));
      // bounds for intervals
      String bounds_name = timeDimName + "_bounds";
      Variable.Builder<?> bounds = Variable.builder().setName(bounds_name).setDataType(DataType.DOUBLE)
          .setParentGroupBuilder(g).setDimensionsByName(timeDimName + " 2");
      g.addVariable(bounds);
      v.addAttribute(new Attribute(CF.BOUNDS, bounds_name));
      bounds.addAttribute(new Attribute(CDM.UNITS, units));
      bounds.addAttribute(new Attribute(CDM.LONG_NAME, "bounds for " + tcName));
      bounds.setSPobject(new Time2Dinfo(Time2DinfoType.boundsU, time2D, null));
    }

    if (runtime.getNCoords() != 1) {
      // for this case we have to generate a separate reftime, because have to use the same dimension
      String refName = "ref" + tcName;
      if (!g.findVariableLocal(refName).isPresent()) {
        Variable.Builder<?> vref = Variable.builder().setName(refName).setDataType(DataType.DOUBLE)
            .setParentGroupBuilder(g).setDimensionsByName(timeDimName);
        g.addVariable(vref);
        vref.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME_REFERENCE));
        vref.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_RUNTIME));
        vref.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));
        vref.addAttribute(new Attribute(CDM.UNITS, units));
        vref.setSPobject(new Time2Dinfo(Time2DinfoType.isUniqueRuntime, time2D, null));
      }
    }
  }

  /*
   * For better compatibility with CF recommendations, the 2D time coordinates should not have the same name as
   * a dimension (a recommendation, but not a strict requirement). 2D time coordinates are now called "validtime{n}",
   * where n is empty or a number (starting with 1). In order to maintain shared dimensions with other time variables,
   * we need to transform that name into a dimension name. It's all pretty simple, but we do it enough times that it
   * gets its own method. Basically, the variable "validtime{n}" will use dimension "time{n}".
   * See https://github.com/Unidata/netcdf-java/issues/152
   */
  private String make2dValidTimeDimensionName(String variableName) {
    return variableName.replaceFirst("valid", "");
  }

  private String make2dValidTimeCoordName(String dimName) {
    return "valid" + dimName;
  }

  private String makeTimeOffsetName(String timeName) {
    return timeName.toLowerCase() + "Offset";
  }

  /*
   * non unique time case
   * 3) time(nruns, ntimes) with reftime(nruns)
   */
  private void makeTimeCoordinate2D(Group.Builder g, CoordinateTime2D time2D, String timeDimName) {
    CoordinateRuntime runtime = time2D.getRuntimeCoordinate();

    int ntimes = time2D.getNtimes();
    String tcName = time2D.getName();
    String dims = runtime.getName() + " " + timeDimName;
    int dimLength = ntimes;

    g.addDimensionIfNotExists(new Dimension(timeDimName, dimLength));
    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(dims);
    g.addVariable(v);
    String units = runtime.getUnit(); // + " since " + runtime.getFirstDate();
    v.addAttribute(new Attribute(CDM.UNITS, units));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_VALID_TIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));
    if (!tcName.equalsIgnoreCase(timeDimName)) {
      // explicitly set the axis type as Time
      v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.Time.toString()));
    }

    // the data is not generated until asked for to save space
    if (!time2D.isTimeInterval()) {
      v.setSPobject(new Time2Dinfo(Time2DinfoType.off, time2D, null));
    } else {
      v.setSPobject(new Time2Dinfo(Time2DinfoType.intv, time2D, null));
      // bounds for intervals
      String bounds_name = tcName + "_bounds";
      Variable.Builder<?> bounds = Variable.builder().setName(bounds_name).setDataType(DataType.DOUBLE)
          .setParentGroupBuilder(g).setDimensionsByName(dims + " 2");
      g.addVariable(bounds);
      v.addAttribute(new Attribute(CF.BOUNDS, bounds_name));
      bounds.addAttribute(new Attribute(CDM.UNITS, units));
      bounds.addAttribute(new Attribute(CDM.LONG_NAME, "bounds for " + tcName));
      bounds.setSPobject(new Time2Dinfo(Time2DinfoType.bounds, time2D, null));
    }

  }

  private void makeTimeCoordinate1D(Group.Builder g, CoordinateTime coordTime) { // }, CoordinateRuntime
    // runtime) {
    int ntimes = coordTime.getSize();
    String tcName = coordTime.getName();
    String dims = coordTime.getName();
    g.addDimension(new Dimension(tcName, ntimes));
    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(dims);
    g.addVariable(v);
    String units = coordTime.getTimeUdUnit();
    v.addAttribute(new Attribute(CDM.UNITS, units));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_VALID_TIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));

    double[] data = new double[ntimes];
    int count = 0;

    // coordinate values
    for (int val : coordTime.getOffsetSorted()) {
      data[count++] = val;
    }
    v.setCachedData(Array.factory(DataType.DOUBLE, new int[] {ntimes}, data), false);

    makeTimeAuxReference(g, tcName, units, coordTime);
  }

  private void makeTimeAuxReference(Group.Builder g, String timeName, String units, CoordinateTimeAbstract time) {
    if (time.getTime2runtime() == null) {
      return;
    }
    String tcName = "ref" + timeName;
    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(timeName);
    g.addVariable(v);
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME_REFERENCE));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_RUNTIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));
    v.addAttribute(new Attribute(CDM.UNITS, units));

    // lazy evaluation
    v.setSPobject(new Time2Dinfo(Time2DinfoType.timeAuxRef, null, time));
  }

  private void makeTimeCoordinate1D(Group.Builder g, CoordinateTimeIntv coordTime) { // }, CoordinateRuntime
    // runtime) {
    int ntimes = coordTime.getSize();
    String tcName = coordTime.getName();
    String dims = coordTime.getName();
    g.addDimension(new Dimension(tcName, ntimes));
    Variable.Builder<?> v = Variable.builder().setName(tcName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(dims);
    g.addVariable(v);
    String units = coordTime.getTimeUdUnit();
    v.addAttribute(new Attribute(CDM.UNITS, units));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME));
    v.addAttribute(new Attribute(CDM.LONG_NAME, Grib.GRIB_VALID_TIME));
    v.addAttribute(new Attribute(CF.CALENDAR, Calendar.proleptic_gregorian.toString()));

    double[] timeCoordValues = new double[ntimes];
    double[] timeCoordBoundsValues = new double[ntimes * 2];
    int count = GribTimeCoordIntervalUtils.generateTimeCoordValuesFromTimeCoordIntervals(coordTime.getTimeIntervals(),
        timeCoordValues, timeCoordBoundsValues, 0, coordTime.getTimeUnit().getValue(), 0);
    assert (count == ntimes);
    v.setCachedData(Array.factory(DataType.DOUBLE, new int[] {ntimes}, timeCoordValues), false);

    // bounds
    String bounds_name = tcName + "_bounds";
    Variable.Builder<?> bounds = Variable.builder().setName(bounds_name).setDataType(DataType.DOUBLE)
        .setParentGroupBuilder(g).setDimensionsByName(dims + " 2");
    g.addVariable(bounds);
    v.addAttribute(new Attribute(CF.BOUNDS, bounds_name));
    bounds.addAttribute(new Attribute(CDM.UNITS, units));
    bounds.addAttribute(new Attribute(CDM.LONG_NAME, "bounds for " + tcName));

    bounds.setCachedData(Array.factory(DataType.DOUBLE, new int[] {ntimes, 2}, timeCoordBoundsValues), false);

    makeTimeAuxReference(g, tcName, units, coordTime);
  }

  private void makeVerticalCoordinate(Group.Builder g, CoordinateVert vc) {
    int n = vc.getSize();
    String vcName = vc.getName().toLowerCase();

    g.addDimension(new Dimension(vcName, n));
    Variable.Builder<?> v = Variable.builder().setName(vcName).setDataType(DataType.FLOAT).setParentGroupBuilder(g)
        .setDimensionsByName(vcName);
    g.addVariable(v);
    if (vc.getUnit() != null) {
      v.addAttribute(new Attribute(CDM.UNITS, vc.getUnit()));
      String desc = iosp.getVerticalCoordDesc(vc.getCode());
      if (desc != null) {
        v.addAttribute(new Attribute(CDM.LONG_NAME, desc));
      }
      v.addAttribute(new Attribute(CF.POSITIVE, vc.isPositiveUp() ? CF.POSITIVE_UP : CF.POSITIVE_DOWN));
    }

    v.addAttribute(new Attribute("Grib_level_type", vc.getCode()));
    VertCoordType vu = vc.getVertUnit();
    if (vu != null) {
      if (vu.getDatum() != null) {
        v.addAttribute(new Attribute("datum", vu.getDatum()));
      }
    }

    if (vc.isLayer()) {
      float[] data = new float[n];
      int count = 0;
      for (VertCoordValue val : vc.getLevelSorted()) {
        data[count++] = (float) (val.getValue1() + val.getValue2()) / 2;
      }
      v.setCachedData(Array.factory(DataType.FLOAT, new int[] {n}, data), false);

      Variable.Builder<?> bounds = Variable.builder().setName(vcName + "_bounds").setDataType(DataType.FLOAT)
          .setParentGroupBuilder(g).setDimensionsByName(vcName + " 2");
      g.addVariable(bounds);
      v.addAttribute(new Attribute(CF.BOUNDS, vcName + "_bounds"));
      String vcUnit = vc.getUnit();
      if (vcUnit != null) {
        bounds.addAttribute(new Attribute(CDM.UNITS, vcUnit));
      }
      bounds.addAttribute(new Attribute(CDM.LONG_NAME, "bounds for " + vcName));

      data = new float[2 * n];
      count = 0;
      for (VertCoordValue level : vc.getLevelSorted()) {
        data[count++] = (float) level.getValue1();
        data[count++] = (float) level.getValue2();
      }
      bounds.setCachedData(Array.factory(DataType.FLOAT, new int[] {n, 2}, data), false);

    } else {
      float[] data = new float[n];
      int count = 0;
      for (VertCoordValue val : vc.getLevelSorted()) {
        data[count++] = (float) val.getValue1();
      }
      v.setCachedData(Array.factory(DataType.FLOAT, new int[] {n}, data), false);
    }
  }

  private void makeEnsembleCoordinate(Group.Builder g, CoordinateEns ec) {
    int n = ec.getSize();
    String ecName = ec.getName().toLowerCase();
    g.addDimension(new Dimension(ecName, n));

    Variable.Builder<?> v = Variable.builder().setName(ecName).setDataType(DataType.INT).setParentGroupBuilder(g)
        .setDimensionsByName(ecName);
    g.addVariable(v);
    v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.Ensemble.toString()));

    int[] data = new int[n];
    int count = 0;
    for (EnsCoordValue ecc : ec.getEnsSorted()) {
      data[count++] = ecc.getEnsMember();
    }
    v.setCachedData(Array.factory(DataType.INT, new int[] {n}, data), false);
  }

  // orthogonal runtime, offset; both independent
  private String makeTimeOffsetOrthogonal(Group.Builder g, CoordinateTime2D time2D) {
    List<?> offsets = time2D.getOffsetsSorted();
    int n = offsets.size();
    String toName = makeTimeOffsetName(time2D.getName());
    g.addDimension(new Dimension(toName, n));

    Variable.Builder<?> v = Variable.builder().setName(toName).setDataType(DataType.DOUBLE).setParentGroupBuilder(g)
        .setDimensionsByName(toName);
    g.addVariable(v);
    v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.TimeOffset.toString()));
    v.addAttribute(new Attribute(CDM.UNITS, time2D.getUnit()));
    v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME_OFFSET));
    v.addAttribute(new Attribute(CDM.LONG_NAME, CDM.TIME_OFFSET));
    v.addAttribute(new Attribute(CDM.UDUNITS, time2D.getTimeUdUnit()));
    v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.TimeOffset.toString()));

    double[] data = new double[n];
    double[] bounds = null;
    int timeUnitValue = time2D.getTimeUnit().getValue();

    if (time2D.isTimeInterval()) {
      bounds = new double[2 * n];
      List<TimeCoordIntvValue> intervals = (List<TimeCoordIntvValue>) offsets;
      // TODO Should this be using 'timeUnitValue'? Wasn't in previous incarnation.
      int count = GribTimeCoordIntervalUtils.generateTimeCoordValuesFromTimeCoordIntervals(intervals, data, bounds, 0,
          timeUnitValue, 0);
      assert (count == n);
    } else {
      int count = 0;
      for (Object val : offsets) {
        Integer off = (Integer) val;
        data[count++] = timeUnitValue * off; // int ??
      }
    }
    v.setCachedData(Array.factory(DataType.DOUBLE, new int[] {n}, data), false);

    if (time2D.isTimeInterval()) {
      String boundsName = toName + "_bounds";
      Variable.Builder<?> coordVarBounds = VariableDS.builder().setName(boundsName).setDataType(DataType.DOUBLE)
          .setDesc("TimeOffset coord bounds").setParentGroupBuilder(g).setDimensionsByName(toName + " 2")
          .setCachedData(Array.factory(DataType.DOUBLE, new int[] {n, 2}, bounds), false);

      g.addVariable(coordVarBounds);

      v.addAttribute(new Attribute(CF.BOUNDS, boundsName));
    }

    return toName;
  }

  // regular runtime, offset; offset depends on runtime hour from 0z
  private String makeTimeOffsetRegular(Group.Builder gb, CoordinateTime2D time2D) {
    try {
      List<Object> hourFrom0z = ImmutableList.copyOf(time2D.getRegularHourOffsets());
      int nhours = hourFrom0z.size();
      int noffsets = time2D.getNtimes();
      String toName = makeTimeOffsetName(time2D.getName());
      gb.addDimension(new Dimension(toName, noffsets));
      String dimNames = nhours + " " + toName;

      Variable.Builder<?> v = Variable.builder().setName(toName).setDataType(DataType.DOUBLE).setParentGroupBuilder(gb)
          .setDimensionsByName(dimNames);
      gb.addVariable(v);
      v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.TimeOffset.toString()));
      v.addAttribute(new Attribute(CDM.UNITS, time2D.getUnit()));
      v.addAttribute(new Attribute(CF.STANDARD_NAME, CF.TIME_OFFSET));
      v.addAttribute(new Attribute(CDM.LONG_NAME, CDM.TIME_OFFSET));
      v.addAttribute(new Attribute(CDM.UDUNITS, time2D.getTimeUdUnit()));
      v.addAttribute(new Attribute(_Coordinate.AxisType, AxisType.TimeOffset.toString()));

      // Special Coordinates. TODO is there a CF equivalent?
      v.addAttribute(
          new Attribute(CDM.RUNTIME_COORDINATE, gb.makeFullName() + time2D.getRuntimeCoordinate().getName()));
      Attribute.Builder attb =
          Attribute.builder(CDM.TIME_OFFSET_HOUR).setDataType(DataType.INT).setValues(hourFrom0z, false);
      v.addAttribute(attb.build());

      // We use a rectangular array; uneven arrays will have NaNs.
      double[] midpoints = new double[nhours * noffsets];
      java.util.Arrays.fill(midpoints, Double.NaN);
      double[] bounds = null;
      if (time2D.isTimeInterval()) {
        bounds = new double[2 * nhours * noffsets];
        java.util.Arrays.fill(bounds, Double.NaN);
        int houridx = 0;
        for (int hour : time2D.getRegularHourOffsets()) {
          CoordinateTimeIntv timeCoord = (CoordinateTimeIntv) time2D.getRegularTimeCoordinate(hour);
          // may be uneven number of values for each hour
          int count = houridx * noffsets;
          int countb = 2 * houridx * noffsets;
          for (TimeCoordIntvValue tinv : timeCoord.getTimeIntervals()) {
            midpoints[count++] = (tinv.getBounds1() + tinv.getBounds2()) / 2.0;
            bounds[countb++] = tinv.getBounds1();
            bounds[countb++] = tinv.getBounds2();
          }
          houridx++;
        }
      } else {
        java.util.Arrays.fill(midpoints, Double.NaN);
        int houridx = 0;
        for (int hour : time2D.getRegularHourOffsets()) {
          CoordinateTime timeCoord = (CoordinateTime) time2D.getRegularTimeCoordinate(hour);
          // may be uneven number of values for each hour
          int count = houridx * noffsets;
          for (Integer offset : timeCoord.getOffsetSorted()) {
            midpoints[count++] = offset;
          }
          houridx++;
        }
      }
      v.setCachedData(Array.factory(DataType.DOUBLE, new int[] {nhours, noffsets}, midpoints), false);

      if (time2D.isTimeInterval()) {
        String boundsName = toName + "_bounds";
        Variable.Builder<?> coordVarBounds = VariableDS.builder().setName(boundsName).setDataType(DataType.DOUBLE)
            .setDesc("time offset coord bounds").setParentGroupBuilder(gb).setDimensionsByName(dimNames + " 2");
        gb.addVariable(coordVarBounds);
        coordVarBounds.setCachedData(Array.factory(DataType.DOUBLE, new int[] {nhours, noffsets, 2}, bounds), false);

        v.addAttribute(new Attribute(CF.BOUNDS, boundsName));
      }
      return toName;
    } catch (Throwable t) {
      logger.error("Error in makeTimeOffsetRegular variable {}", makeTimeOffsetName(time2D.getName()), t);
      throw new RuntimeException(t);
    }
  }
}
